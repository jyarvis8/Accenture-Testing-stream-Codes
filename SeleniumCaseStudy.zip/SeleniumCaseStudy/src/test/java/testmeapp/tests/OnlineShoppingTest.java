package testmeapp.tests;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import testmeapp.utility.Drivers;

public class OnlineShoppingTest {
	ExtentSparkReporter htmlReporter;
	ExtentReports extent;
	ExtentTest Logger;
	WebDriver driver;

	@Test(priority=1)
	public void testRegistration() {
		Logger=extent.createTest("method1report");
		driver.get("https://lkmdemoaut.accenture.com/TestMeApp/fetchcat.htm");
		driver.findElement(By.xpath("//a[@href='RegisterUser.htm']")).click();
		Assert.assertEquals(driver.getTitle(), "Sign Up");
		driver.findElement(By.xpath("//input[@name='userName']")).sendKeys("6564888");
		driver.findElement(By.xpath("//input[@name='firstName']")).sendKeys("kgkgkht");

		WebDriverWait wait = new WebDriverWait(driver,5);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[contains(text(),'Available')]")));

		driver.findElement(By.xpath("//input[@name='lastName']")).sendKeys("kfjgjgj");
		driver.findElement(By.xpath("//input[@name='password']")).sendKeys("123456");
		driver.findElement(By.xpath("//input[@name='confirmPassword']")).sendKeys(
				"123456"); driver.findElement(By.xpath("//input[@value='Male']")).click();
				driver.findElement(By.xpath("//input[@name='emailAddress']")).sendKeys("jfjjg@gkjfk.mdjfg");
				driver.findElement(By.xpath("//input[@name='mobileNumber']")).sendKeys("9586748576");
				driver.findElement(By.xpath("//input[@name='dob']")).sendKeys("947583");
				driver.findElement(By.xpath("//textarea[@id='address']")).sendKeys("kjikfjhjsjf");

				Select secQ = new Select(driver.findElement(By.xpath("//select[@id='securityQuestion']")));
				secQ.selectByIndex(1);
				driver.findElement(By.xpath("//input[@name='answer']")).sendKeys("kjdkjdkgjkkd");
				driver.findElement(By.xpath("//input[@type='submit']")).click();
				Assert.assertEquals(driver.getTitle(), "Login"); 
				String msg =driver.findElement(By.xpath("//div[contains(text(),' User Registered Succesfully!!! Please login')]")).getText(); 
				Assert.assertEquals(msg,"User Registered Succesfully!!! Please login");
	}
	
	@Test (priority=2)
	public void testLogin() { 
		Logger=extent.createTest("method2report");
		Assert.assertEquals(driver.getTitle(), "Login");

		driver.findElement(By.id("userName")).sendKeys("871998");
		driver.findElement(By.id("password")).sendKeys("123456");
		driver.findElement(By.name("Login")).click();

		Assert.assertEquals(driver.getTitle(), "Home");
		Boolean logout=driver.findElement(By.linkText("SignOut")).isDisplayed();
		Assert.assertTrue(logout);
	}
	
	@Test(priority=3)
	public void testCart() {
		Logger=extent.createTest("method3report");
		Assert.assertEquals(driver.getTitle(), "Home");
		driver.findElement(By.xpath("//input[@id='myInput']")).sendKeys("Gift Set");
		driver.findElement(By.xpath("//input[@type='submit']")).click();
		driver.findElement(By.xpath("//a[@class='btn btn-success btn-product']")).click();
		Boolean success=driver.findElement(By.xpath("//h3[contains(text(),'Sorry no products available in this category. Please try some other')]")).isDisplayed();
		Assert.assertTrue(success);
	}
	
	@Test(priority=4)
	public void testPayment() {
		Logger=extent.createTest("method4report");
		driver.findElement(By.partialLinkText("Cart")).click();
		Assert.assertEquals(driver.getTitle(), "View Cart");
		driver.findElement(By.partialLinkText("Checkout")).click();
		driver.findElement(By.xpath("//input[@value=\"Proceed to Pay\"]")).click();

		WebDriverWait wait = new WebDriverWait(driver,5);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//h2[contains(text(),'Welcome to Payment Gateway - ')]")));
		
		driver.findElement(By.xpath("//*[@id=\"swit\"]/div[1]/div/label/i")).click();
		driver.findElement(By.xpath("//a[@href=\"#\"]")).click();
		driver.findElement(By.name("username")).sendKeys("123456");
		driver.findElement(By.name("password")).sendKeys("Pass@456");
		driver.findElement(By.xpath("//input[@value=\"LOGIN\"]")).click();
		driver.findElement(By.xpath("//input[@type=\"password\"]")).sendKeys("Trans@456");
		driver.findElement(By.xpath("//input[@type=\"submit\"]")).click();
		Boolean successfull=driver.findElement(By.xpath("//p[contains(text(),'Your order has been confirmed')]")).isDisplayed();
		Assert.assertTrue(successfull);

	}
	@AfterMethod
	public void afterMethod(ITestResult result) {
		if(result.getStatus()==ITestResult.SUCCESS) {
			Logger.log(Status.PASS,"This is in "+result.getMethod().getMethodName());
		}else if(result.getStatus()==ITestResult.FAILURE) {
			Logger.log(Status.FAIL,"This is in "+result.getMethod().getMethodName());  
			TakesScreenshot screenshot=(TakesScreenshot) driver;    //function for taking screenshot
			File srcfile=screenshot.getScreenshotAs(OutputType.FILE);
			String destfile=System.getProperty("user.dir")+"/extent-reports"+result.getMethod().getMethodName()+".png";
			try {
				FileUtils.copyFile(srcfile, new File(destfile));
				Logger.addScreenCaptureFromPath(destfile);     //function for attaching screenshot
				Logger.log(Status.FAIL,result.getThrowable().getMessage());
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else if(result.getStatus()==ITestResult.SKIP) {
			Logger.log(Status.SKIP,"This is in "+result.getMethod().getMethodName());
		}
	}

	@BeforeTest
	public void startReportBeforeTest() {
		driver=Drivers.getDriver("chrome");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd-hh-mm-ss-ms");  //function for changing name of new report
		String filepath=System.getProperty("user.dir")+"/extent-reports/"+sdf.format(new Date())+".html";
		
		htmlReporter =new ExtentSparkReporter(filepath); 
		extent=new ExtentReports();
		extent.attachReporter(htmlReporter);
	}

	@AfterTest
	public void afterTest() {
		driver.close();
		extent.flush();
	}

}
