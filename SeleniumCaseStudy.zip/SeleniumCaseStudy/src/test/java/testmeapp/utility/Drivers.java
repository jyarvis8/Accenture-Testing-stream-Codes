package testmeapp.utility;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.WebDriver;

public class Drivers {
  
  static public WebDriver getDriver(String browserName) {
	  if(browserName.equals("chrome")) {
			System.setProperty("webdriver.chrome.driver","src/test/resources/chromedriver.exe");
			return new ChromeDriver();
		}else if(browserName.equals("firefox")) {
			System.setProperty("webdriver.gecko.driver", "src/test/resources/geckodriver.exe");
			return new FirefoxDriver();
		}else if(browserName.equals("ie")) {
			System.setProperty("webdriver.ie.driver", "src/test/resources/IEDriverServer.exe");
			return new InternetExplorerDriver();
		}else {
			return null;
		}
	  
  }
}
