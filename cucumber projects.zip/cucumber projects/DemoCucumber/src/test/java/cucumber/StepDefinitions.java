package cucumber;


import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.pages.LoginPageObject;

import io.cucumber.java.After;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;



public class StepDefinitions {
	WebDriver driver;
	private LoginPageObject LPO;
	
	@Given("user opens TestMe App")
	public void user_opens_test_me_app() {
		System.setProperty("webdriver.chrome.driver","src/test/resources/chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://lkmdemoaut.accenture.com/TestMeApp/fetchcat.htm");
		driver.findElement(By.linkText("SignIn")).click();
		LPO = new LoginPageObject(driver);
	}
	@When("entered wrong credentials")
	public void entered_wrong_credentials() {
//		driver.findElement(By.id("userName")).sendKeys("12345777");
//		driver.findElement(By.id("password")).sendKeys("123456");
		LPO.Login("joe123", "pass123");
	}
	@When("Presses login button")
	public void presses_login_button() {
		driver.findElement(By.name("Login")).click();

	}
	@Then("Login page remains open")
	public void login_page_remains_open() {
		Assert.assertEquals("Login", driver.getTitle());
	}
	
	
	@When("user enters wrong {string} and {string}")
	public void user_enters_wrong_and(String string, String pwd) {
		driver.findElement(By.id("userName")).sendKeys(string);
		driver.findElement(By.id("password")).sendKeys(pwd);
	}
	
	
	@After
	public void close_browser() {
		driver.quit();
	}
}
