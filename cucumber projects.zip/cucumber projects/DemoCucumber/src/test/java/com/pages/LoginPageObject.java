package com.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class LoginPageObject {
	@FindBy(how=How.ID,using="userName")
	private WebElement uname;
	
	@FindBy(how=How.ID,using="password")
	private WebElement pwd;
	
	@FindBy(how=How.NAME,using="Login")
	private WebElement login_button;
	
	private WebDriver driver;
	
	public LoginPageObject(WebDriver driver) {      //constructor
		this.driver=driver;
		PageFactory.initElements(this.driver,this);
	}
	
	public void Login(String usname,String pass) {  //login_method
		uname.sendKeys(usname);
		pwd.sendKeys(pass);
		login_button.click();
	}
	
}
