package Util;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class BaseUtil {
	static public WebDriver getBrowserInstance(String browserName) {
		if(browserName.equals("chrome")) {
			System.setProperty("webdriver.chrome.driver","src/test/resources/chromedriver.exe");
			return new ChromeDriver();
		}else if(browserName.equals("firefox")) {
			
		}else if(browserName.equals("ie")) {
			
		}else {
			return null;
		}
		return null;
		
	}
}
