package tests;

import org.testng.annotations.Test;
import Util.BaseUtil;
import org.testng.annotations.BeforeClass;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;

public class TestClass01 {
	WebDriver driver;
  @Test
  public void Method1() {
	  driver.get("https://lkmdemoaut.accenture.com/TestMeApp/fetchcat.htm");
  }
  @BeforeClass
  public void beforeClass() {
	  driver=BaseUtil.getBrowserInstance("chrome");
	  driver.manage().window().maximize();
  }

  @AfterClass
  public void afterClass() {
	  driver.close();
  }

}
