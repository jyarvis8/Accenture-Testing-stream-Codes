package tests;

import org.testng.annotations.Test;

import Util.BaseUtil;

import org.testng.annotations.BeforeClass;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.AfterClass;

public class Ex23_2 {
	WebDriver driver;
	@Test
	public void orderDetails() {
		driver.get("https://lkmdemoaut.accenture.com/TestMeApp/fetchcat.htm");
		Assert.assertEquals(driver.getTitle(), "Home");

		driver.findElement(By.linkText("SignIn")).click();
		Assert.assertEquals(driver.getTitle(), "Login");

		driver.findElement(By.id("userName")).sendKeys("871998");
		driver.findElement(By.id("password")).sendKeys("123456");
		driver.findElement(By.name("Login")).click();

		Assert.assertEquals(driver.getTitle(), "Home");
		driver.findElement(By.xpath("//input[@id='myInput']")).sendKeys("Gift Set");
		driver.findElement(By.xpath("//input[@type='submit']")).click();
		driver.findElement(By.xpath("//a[@class='btn btn-success btn-product']")).click();
		driver.navigate().to("https://lkmdemoaut.accenture.com/TestMeApp/fetchcat.htm");
		driver.findElement(By.xpath("//input[@id='myInput']")).sendKeys("Hand bag");
		driver.findElement(By.xpath("//input[@type='submit']")).click();
		driver.findElement(By.xpath("//a[@class='btn btn-success btn-product']")).click();
		driver.findElement(By.xpath("//a[@href='displayCart.htm']")).click();
		
		

		List<WebElement> rows = driver.findElements(By.tagName("tr"));
		int noofrows = rows.size() - 3;
		if(noofrows>=0) {
			System.out.println("No of Items in cart are: "+noofrows);
		}else {
			System.out.println("Order Table Empty");
		}




	}
	@BeforeClass
	public void beforeClass() {
		driver=BaseUtil.getBrowserInstance("chrome");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@AfterClass
	public void afterClass() {
		driver.close();
	}

}
