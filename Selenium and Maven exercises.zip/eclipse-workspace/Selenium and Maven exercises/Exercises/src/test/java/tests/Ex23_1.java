package tests;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import Util.BaseUtil;

public class Ex23_1 {
	WebDriver driver;
	@Test
	public void testMethod() {
		driver.get("https://lkmdemoaut.accenture.com/TestMeApp/fetchcat.htm");
		driver.findElement(By.xpath("//a[@href='RegisterUser.htm']")).click();
		Assert.assertEquals(driver.getTitle(), "Sign Up");
		driver.findElement(By.xpath("//input[@name='userName']")).sendKeys("8764544");
		driver.findElement(By.xpath("//input[@name='firstName']")).sendKeys("abcdef"); 

		WebDriverWait wait = new WebDriverWait(driver,5);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[contains(text(),'Available')]")));

		driver.findElement(By.xpath("//input[@name='lastName']")).sendKeys("abcdef");
		driver.findElement(By.xpath("//input[@name='password']")).sendKeys("123456");
		driver.findElement(By.xpath("//input[@name='confirmPassword']")).sendKeys("123456");
		driver.findElement(By.xpath("//input[@value='Male']")).click();
		driver.findElement(By.xpath("//input[@name='emailAddress']")).sendKeys("abc@xyz.com");
		driver.findElement(By.xpath("//input[@name='mobileNumber']")).sendKeys("0123456789");
		driver.findElement(By.xpath("//input[@name='dob']")).sendKeys("123456");
		driver.findElement(By.xpath("//textarea[@id='address']")).sendKeys("wjsujbwevujbevwubhvie");


		Select secQ = new Select(driver.findElement(By.xpath("//select[@id='securityQuestion']")));
		secQ.selectByIndex(3);
		driver.findElement(By.xpath("//input[@name='answer']")).sendKeys("sdfdg");

		driver.findElement(By.xpath("//input[@type='submit']")).click();
		Assert.assertEquals(driver.getTitle(), "Login");
		String msg = driver.findElement(By.xpath("//div[contains(text(),' User Registered Succesfully!!! Please login')]")).getText();
		Assert.assertEquals(msg, "User Registered Succesfully!!! Please login");	  
	}
	
	@BeforeClass
	public void beforeClass() {
		driver=BaseUtil.getBrowserInstance("chrome");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);

	}

	@AfterClass
	public void afterClass() {
		driver.close();
	}

}
