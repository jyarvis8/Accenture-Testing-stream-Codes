package tests;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import Util.BaseUtil;

public class Ex24 {
	WebDriver driver;
	@BeforeClass
	public void beforeClass() {
		driver=BaseUtil.getBrowserInstance("chrome");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@AfterClass
	public void afterClass() {
		driver.close();
	}
	@Test
	public void f() {
		driver.get("https://lkmdemoaut.accenture.com/TestMeApp/fetchcat.htm");
		Assert.assertEquals(driver.getTitle(), "Home");
		WebElement searchbox=driver.findElement(By.xpath("//input[@id='myInput']"));


		Actions action = new Actions(driver);
		action
		.sendKeys(searchbox, "w").pause(1000)
		.sendKeys(searchbox, "e").pause(1000)
		.sendKeys(searchbox, "a").pause(1000)
		.sendKeys(searchbox, "r").pause(1000)
		.build().perform();

		WebElement item=driver.findElement(By.xpath("//div[contains(text(),'Summer wear')]"));
		action.moveToElement(item).click().build().perform();
		driver.findElement(By.xpath("//input[@type='submit']")).click();
		Assert.assertEquals(driver.findElement(By.xpath("//h4[contains(text(),'Summer wear')]")).getText(), "Summer wear");


	}
}
