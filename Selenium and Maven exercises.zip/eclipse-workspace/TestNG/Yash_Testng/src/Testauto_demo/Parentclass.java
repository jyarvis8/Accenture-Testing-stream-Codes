package Testauto_demo;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.AfterSuite;

public class Parentclass {
 
  @BeforeTest
  public void beforeTest() {
	  System.out.println("in before test");
  }

  @AfterTest
  public void afterTest() {
	  System.out.println("in After test");
  }

  @BeforeSuite
  public void beforeSuite() {
	  System.out.println("in before testsuite");
  }

  @AfterSuite
  public void afterSuite() {
	  System.out.println("in after testsuite");
  }

}
