package Testauto_demo;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class Testclass1 extends Parentclass {
  @Test
  public void Method1() {
	  SoftAssert sa = new SoftAssert();
	  Assert.assertTrue(10>5);
	  sa.assertTrue(10>5);
	  System.out.println("Class1:Inside method 1");
	  sa.assertAll();
  }
}
