package Testauto_demo;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class Annotationdemo extends Parentclass {
	@BeforeClass
	public void BeforeC() {
		System.out.println("In before class");
	}
	@AfterClass
	public void AfterC() {
		System.out.println("In after class");
	}
     
	 @BeforeMethod
	public void BeforeM() {
		System.out.println("In before Method");
	}
	@AfterMethod
	public void AfterM() {
		System.out.println("In after Method");
	}
	
	
  @Test(priority=1)
  public void Method1() {
	  System.out.println("class2:Inside Method 1");
	  Assert.assertTrue(20<18);
  }
  @Test(priority=0)
  public void Method2() {
	  System.out.println("class2:Inside Method 2");
  }
}
