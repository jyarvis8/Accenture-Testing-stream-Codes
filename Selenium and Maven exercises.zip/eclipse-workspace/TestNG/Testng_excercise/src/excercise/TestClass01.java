package excercise;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterClass;

public class TestClass01 {
  @Test(priority = 1)
  public void tMethod1() {
  }
  @Test(priority = 0)
  public void tMethod2() {
  }
  @Test
  public void tMethod5() {
  }
  @BeforeMethod
  public void beforeMethod() {
  }

  @AfterClass
  public void afterClass() {
  }

}
