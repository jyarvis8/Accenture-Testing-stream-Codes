package excercise;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterClass;

public class TestClass02 {
  @Test
  public void tMethod3() {
  }
  @Test
  public void tMethod4() {
  }
  @BeforeMethod
  public void beforeMethod() {
  }

  @AfterClass
  public void afterClass() {
  }

}
